Game.preloader_NS_RN_G8 = function (game) {
        this.preloadBar = null;
};

var chime, clockTick;
Game.preloader_NS_RN_G8.prototype = {
        preload: function () {
                // this.load.video('NS-RN-G8_1', 'demoVideos/NS-RN-G8.mp4');   //* include demo video of game.
                this.load.image('skipArrow', 'assets/commonAssets/skipArrow.png');

                this.load.atlas('bulb', 'assets/commonAssets/bulb.png', null, NS_RN_G8_JSON.bulbBtnJson);

                this.load.atlas('backbtn', 'assets/commonAssets/backbtn.png', null, NS_RN_G8_JSON.backbtnJson);
                this.load.atlas('CommonSpeakerBtn', 'assets/commonAssets/speaker.png', null, NS_RN_G8_JSON.speakerJson);
                this.load.atlas('starAnim', 'assets/commonAssets/starAnim.png', null, NS_RN_G8_JSON.starAnimJson);
                this.load.atlas('replay', 'assets/commonAssets/reply.png', null, NS_RN_G8_JSON.replyJson);

                this.load.image('navBar', 'assets/commonAssets/navBar.png');
                this.load.image('timebg', 'assets/commonAssets/timebg.png');
                 this.load.image('hand', 'assets/commonAssets/hand.png');

                this.load.atlas('CommonHomeBtn', 'assets/commonAssets/homeBtn.png', null, NS_RN_G8_JSON.homebtnJson);
                this.load.atlas('CommonNextBtn', 'assets/commonAssets/nextBtn.png', null, NS_RN_G8_JSON.nextbtnJson);

                //game grade assets


                this.load.image('BG', 'assets/gradeAssets/NS-RN-G8/bg.png');
                this.load.image('panel', 'assets/gradeAssets/NS-RN-G8/box.png');
                this.load.image('hand', 'assets/gradeAssets/NS-RN-G8/hand.png');
                

                // this.load.image('greenBall', 'assets/gradeAssets/NS-RN-G8/green ball.png');
                // this.load.image('pinkBall', 'assets/gradeAssets/NS-RN-G8/pink ball.png');
                // this.load.image('orangeBall','assets/gradeAssets/NS-RN-G8/Orange ball.png');

                this.load.image('scale', 'assets/gradeAssets/NS-RN-G8/scale.png');

                // this.load.image('wheelO', 'assets/gradeAssets/NS-RN-G8/weel 2.png');
                // this.load.image('bombG', 'assets/gradeAssets/NS-RN-G8/weel 4.png');
                // this.load.image('bombO', 'assets/gradeAssets/NS-RN-G8/weel 3.png');
                // this.load.image('wick1', 'assets/gradeAssets/NS-RN-G8/object_1.png');
                // this.load.image('wick2', 'assets/gradeAssets/NS-RN-G8/object_2.png');
                this.load.atlas('text', 'assets/gradeAssets/NS-RN-G8/text.png', null, NS_RN_G8_JSON.textJson);

                this.load.atlas('blueCircle','assets/gradeAssets/NS-RN-G8/blue circle.png',null, NS_RN_G8_JSON.blueCircleJson);   
                this.load.atlas('greenCircle', 'assets/gradeAssets/NS-RN-G8/green circle.png', null, NS_RN_G8_JSON.greenCircleJson);
                this.load.atlas('orangeCircle','assets/gradeAssets/NS-RN-G8/orange circle.png',null, NS_RN_G8_JSON.orangeCircleJson);   
                this.load.atlas('yellowCircle', 'assets/gradeAssets/NS-RN-G8/yellow circle.png', null, NS_RN_G8_JSON.yellowCircleJson);

                this.load.atlas('greenBall','assets/gradeAssets/NS-RN-G8/green ball.png',null, NS_RN_G8_JSON.greenBallJson);   
                this.load.atlas('pinkBall', 'assets/gradeAssets/NS-RN-G8/pink ball.png', null, NS_RN_G8_JSON.pinkBallJson);

                this.load.atlas('RedBall','assets/gradeAssets/NS-RN-G8/red ball.png',null, NS_RN_G8_JSON.redBallJson);   
                // this.load.atlas('yellowBlast', 'assets/gradeAssets/NS-RN-G8/yellow blast.png', null, NS_RN_G8_JSON.yellowBlastJson);
  
        },

        create: function () {

                this.state.start('NS_RN_G8level1');
        },
}