Game.preloader_GMM_05_G8 = function (game) {
        this.preloadBar = null;
};

var chime, clockTick;
Game.preloader_GMM_05_G8.prototype = {
        preload: function () {

                // this.load.video('ML1_1', 'demoVideos/ML1-G7_1.mp4');   //* include demo video of ML-2 game.
                // this.load.video('ML1_2', 'demoVideos/ML1-G7_2.mp4');   //* include demo video of ML-2 game.

                this.load.atlas('bulb', 'assets/commonAssets/bulb.png', null, GMM_05_G8_JSON.bulbBtnJson);
                this.load.image('skipArrow', 'assets/commonAssets/skipArrow.png');

                this.load.atlas('backbtn', 'assets/commonAssets/backbtn.png', null, GMM_05_G8_JSON.backbtnJson);
                this.load.atlas('CommonSpeakerBtn', 'assets/commonAssets/speaker.png', null, GMM_05_G8_JSON.speakerJson);
                this.load.atlas('starAnim', 'assets/commonAssets/starAnim.png', null, GMM_05_G8_JSON.starAnimJson);
                this.load.atlas('replay', 'assets/commonAssets/reply.png', null, GMM_05_G8_JSON.replyJson);
                this.load.image('navBar', 'assets/commonAssets/navBar.png');
                this.load.image('timebg', 'assets/commonAssets/timebg.png');
                this.load.image('hand', 'assets/commonAssets/hand.png');
                this.load.atlas('CommonHomeBtn', 'assets/commonAssets/homeBtn.png', null, GMM_05_G8_JSON.homebtnJson);
                this.load.atlas('CommonNextBtn', 'assets/commonAssets/nextBtn.png', null, GMM_05_G8_JSON.nextbtnJson);
                this.load.image('bg', 'assets/gradeAssets/GMM-05-G8/BG.png');


                this.load.image('dottedCircle', 'assets/gradeAssets/GMM-05-G8/blue doted circle 10 by 1.png');
                this.load.atlas('box1', 'assets/gradeAssets/GMM-05-G8/box1.png', null, GMM_05_G8_JSON.box1);
                this.load.image('Box2', 'assets/gradeAssets/GMM-05-G8/box2.png');
                this.load.atlas('btn1', 'assets/gradeAssets/GMM-05-G8/btn_1.png', null, GMM_05_G8_JSON.btn1)
                this.load.atlas('eraser', 'assets/gradeAssets/GMM-05-G8/btn_2.png', null, GMM_05_G8_JSON.btn2)
                this.load.image('cylinder', 'assets/gradeAssets/GMM-05-G8/cylinder shape.png');
             
                this.load.image('orangeArrow', 'assets/gradeAssets/GMM-05-G8/orange arrow.png');
                this.load.image('orangeTr', 'assets/gradeAssets/GMM-05-G8/orange arrow_1.png');
                this.load.image('panle1', 'assets/gradeAssets/GMM-05-G8/panle_1.png');
                this.load.image('panle3', 'assets/gradeAssets/GMM-05-G8/panle_3.png');
                this.load.image('panle4', 'assets/gradeAssets/GMM-05-G8/panle_4.png');
                this.load.atlas('panle7', 'assets/gradeAssets/GMM-05-G8/panle_7.png', null, GMM_05_G8_JSON.panle7)
                this.load.image('answerBox', 'assets/gradeAssets/GMM-05-G8/text box.png');
                this.load.atlas('textBox2', 'assets/gradeAssets/GMM-05-G8/text box_2.png', null, GMM_05_G8_JSON.textBox2);
                this.load.image('textBox1table', 'assets/gradeAssets/GMM-05-G8/text box_1.png');
                this.load.image('textBox2table', 'assets/gradeAssets/GMM-05-G8/text box_2 (2).png');
                this.load.image('textBox12', 'assets/gradeAssets/GMM-05-G8/text box_120001.png');
                this.load.image('textBox12Y', 'assets/gradeAssets/GMM-05-G8/text box_120002.png');

                this.load.atlas('textBox3', 'assets/gradeAssets/GMM-05-G8/text box_3.png', null, GMM_05_G8_JSON.textbox3)
                this.load.atlas('textBox4', 'assets/gradeAssets/GMM-05-G8/text box_4.png', null, GMM_05_G8_JSON.textBox4)
                this.load.atlas('TickBtn', 'assets/gradeAssets/GMM-05-G8/TickBtn.png', null, GMM_05_G8_JSON.tickJson);

                this.load.image('blueCircle', 'assets/gradeAssets/GMM-05-G8/blue doted circle.png');
                this.load.image('text_box_15', 'assets/gradeAssets/GMM-05-G8/text box_15.png');
                this.load.image('transCylinder', 'assets/gradeAssets/GMM-05-G8/cylinder shape 2.png');
                // this.load.image('transCylinder', 'assets/gradeAssets/GMM-05-G8/cylinder trans shape.png');
        },

        create: function () {
                this.state.start('GMM_05_G8level1');
        },
}