Game.preloader_GMSS_03_G8 = function (game) {
        this.preloadBar = null;
};

var chime, clockTick;
Game.preloader_GMSS_03_G8.prototype = {
        preload: function () {
                //  this.load.video('nsrp02_1','demoVideos/AL-SUB-G7.mp4');   //* include demo video of game.
                this.load.image('skipArrow', 'assets/commonAssets/skipArrow.png');

                this.load.atlas('bulb', 'assets/commonAssets/bulb.png', null, GMSS_03_G8_JSON.bulbBtnJson);

                this.load.atlas('backbtn', 'assets/commonAssets/backbtn.png', null, GMSS_03_G8_JSON.backbtnJson);
                this.load.atlas('CommonSpeakerBtn', 'assets/commonAssets/speaker.png', null, GMSS_03_G8_JSON.speakerJson);
                this.load.atlas('starAnim', 'assets/commonAssets/starAnim.png', null, GMSS_03_G8_JSON.starAnimJson);
                this.load.atlas('replay', 'assets/commonAssets/reply.png', null, GMSS_03_G8_JSON.replyJson);
                this.load.image('navBar', 'assets/commonAssets/navBar.png');
                this.load.image('timebg', 'assets/commonAssets/timebg.png');
                this.load.image('hand', 'assets/commonAssets/hand.png');

                this.load.atlas('CommonHomeBtn', 'assets/commonAssets/homeBtn.png', null, GMSS_03_G8_JSON.homebtnJson);
                this.load.atlas('CommonNextBtn', 'assets/commonAssets/nextBtn.png', null, GMSS_03_G8_JSON.nextbtnJson);

                this.load.image('BG1', 'assets/gradeAssets/GMSS-03-G8/Bg.png');

                //Boxes
                this.load.image('Box_1', 'assets/gradeAssets/GMSS-03-G8/Box_1.png');
                this.load.image('Box_2', 'assets/gradeAssets/GMSS-03-G8/Box_2.png');//GMSS-03-G8\assets\gradeAssets\GMSS-03-G8\New folder
                //  this.load.atlas('Box_2', 'assets/gradeAssets/GMSS-03-G8/box.png', null, GMSS_03_G8_JSON.Bx2frame);
                this.load.atlas('Box_2', 'assets/gradeAssets/GMSS-03-G8/Box_2new.png', null, GMSS_03_G8_JSON.box2New);

                this.load.image('Box_3', 'assets/gradeAssets/GMSS-03-G8/Box_3.png');
                this.load.image('Box_4', 'assets/gradeAssets/GMSS-03-G8/Box_4.png');
                this.load.atlas('TickBtn', 'assets/gradeAssets/GMSS-03-G8/TickBtn.png', null, GMSS_03_G8_JSON.tickJson);
                // this.load.atlas('box 2', 'assets/gradeAssets/GMSS-03-G8/box 2.png', null, GMSS_03_G8_JSON.Box2);

                this.load.atlas('Box2', 'assets/gradeAssets/GMSS-03-G8/box 2.png', null, GMSS_03_G8_JSON.Box2);
                this.load.image('Box1', 'assets/gradeAssets/GMSS-03-G8/box11.png');

                //Torch
                this.load.image('txt1', 'assets/gradeAssets/GMSS-03-G8/text box_1.png');
                this.load.image('txt2', 'assets/gradeAssets/GMSS-03-G8/text box_2.png');

                // Part A 3D objects here goes
                this.load.image('VpinkTriangle', 'assets/gradeAssets/GMSS-03-G8/3D shape _1.png');
                this.load.image('HpinkTriangle', 'assets/gradeAssets/GMSS-03-G8/3D shape _2.png');
                this.load.image('Hprism', 'assets/gradeAssets/GMSS-03-G8/3D shape _3.png');
                this.load.image('Vprism', 'assets/gradeAssets/GMSS-03-G8/3D shape _4.png');
                this.load.image('Vcone', 'assets/gradeAssets/GMSS-03-G8/3D shape _5.png');
                this.load.image('Hcone', 'assets/gradeAssets/GMSS-03-G8/3D shape _6.png');
                this.load.image('cube', 'assets/gradeAssets/GMSS-03-G8/3D shape _7.png');
                this.load.image('VblueTriangle', 'assets/gradeAssets/GMSS-03-G8/3D shape _8.png');
                this.load.image('Vcylinder', 'assets/gradeAssets/GMSS-03-G8/3D shape _9.png');
                this.load.image('Hcylinder', 'assets/gradeAssets/GMSS-03-G8/3D shape _10.png');
                this.load.image('cuboid', 'assets/gradeAssets/GMSS-03-G8/3D shape _11.png');

                //Part B shapes 
                this.load.image('obj1', 'assets/gradeAssets/GMSS-03-G8/object_1.png');
                this.load.image('obj2', 'assets/gradeAssets/GMSS-03-G8/object_2.png');
                this.load.image('obj3', 'assets/gradeAssets/GMSS-03-G8/object_3.png');
                this.load.image('obj4', 'assets/gradeAssets/GMSS-03-G8/object_4.png');
                this.load.image('obj5', 'assets/gradeAssets/GMSS-03-G8/object_5.png');
                this.load.image('obj6', 'assets/gradeAssets/GMSS-03-G8/object_6.png');
                this.load.image('obj7', 'assets/gradeAssets/GMSS-03-G8/object_7.png');
                this.load.image('obj8', 'assets/gradeAssets/GMSS-03-G8/object_8.png');
                this.load.image('obj9', 'assets/gradeAssets/GMSS-03-G8/object_9.png');
                this.load.image('obj10', 'assets/gradeAssets/GMSS-03-G8/object_10.png');
                this.load.image('obj11', 'assets/gradeAssets/GMSS-03-G8/object_11.png');
                this.load.image('obj12', 'assets/gradeAssets/GMSS-03-G8/object_12.png');
                this.load.image('obj13', 'assets/gradeAssets/GMSS-03-G8/object_13.png');
                this.load.image('obj14', 'assets/gradeAssets/GMSS-03-G8/object_14.png');
                this.load.image('obj15', 'assets/gradeAssets/GMSS-03-G8/object_15.png');
                this.load.image('obj16', 'assets/gradeAssets/GMSS-03-G8/object_16.png');
                this.load.image('obj17', 'assets/gradeAssets/GMSS-03-G8/object_17.png');

                this.load.image('numpadbg', 'assets/gradeAssets/GMSS-03-G8/numbg.png');
                this.load.atlas('Numberpad', 'assets/gradeAssets/GMSS-03-G8/number pad.png', null, GMSS_03_G8_JSON.numberpadJson);
        },

        create: function () {

                this.state.start('GMSS_03_G8level1');
        },
}