var GMSS_03_G8_JSON = {

	answerBoxJson: {
		"frames": [

			{
				"filename": "Symbol 14 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 63, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 63, "h": 47 },
				"sourceSize": { "w": 63, "h": 47 }
			}
			, {
				"filename": "Symbol 14 instance 10001",
				"frame": { "x": 63, "y": 0, "w": 63, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 63, "h": 47 },
				"sourceSize": { "w": 63, "h": 47 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "text box_5.png",
			"format": "RGBA8888",
			"size": { "w": 127, "h": 47 },
			"scale": "1"
		}
	},
	starAnimJson: {
		"frames": [

			{
				"filename": "Symbol 10 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10001",
				"frame": { "x": 0, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10002",
				"frame": { "x": 0, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10003",
				"frame": { "x": 0, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10004",
				"frame": { "x": 33, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10005",
				"frame": { "x": 33, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10006",
				"frame": { "x": 33, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10007",
				"frame": { "x": 33, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10008",
				"frame": { "x": 66, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10009",
				"frame": { "x": 66, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10010",
				"frame": { "x": 66, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10011",
				"frame": { "x": 66, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10012",
				"frame": { "x": 99, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10013",
				"frame": { "x": 99, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10014",
				"frame": { "x": 99, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10015",
				"frame": { "x": 99, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10016",
				"frame": { "x": 132, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10017",
				"frame": { "x": 132, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10018",
				"frame": { "x": 132, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10019",
				"frame": { "x": 132, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10020",
				"frame": { "x": 165, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10021",
				"frame": { "x": 165, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10022",
				"frame": { "x": 165, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10023",
				"frame": { "x": 165, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10024",
				"frame": { "x": 198, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10025",
				"frame": { "x": 198, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10026",
				"frame": { "x": 198, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10027",
				"frame": { "x": 198, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10028",
				"frame": { "x": 231, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10029",
				"frame": { "x": 231, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10030",
				"frame": { "x": 231, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10031",
				"frame": { "x": 231, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10032",
				"frame": { "x": 264, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10033",
				"frame": { "x": 264, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10034",
				"frame": { "x": 264, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10035",
				"frame": { "x": 264, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "st.png",
			"format": "RGB8",
			"size": { "w": 334, "h": 479 },
			"scale": "1"
		}
	},

	numberpadJson: {"frames": [

		{
			"filename": "Symbol 3 copy instance 10000",
			"frame": {"x":0,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 3 copy instance 10001",
			"frame": {"x":68,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 3 copy instance 10002",
			"frame": {"x":136,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 3 copy instance 10003",
			"frame": {"x":204,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 3 copy instance 10004",
			"frame": {"x":272,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 3 copy instance 10005",
			"frame": {"x":340,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 3 copy instance 10006",
			"frame": {"x":408,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 3 copy instance 10007",
			"frame": {"x":476,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 3 copy instance 10008",
			"frame": {"x":544,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 3 copy instance 10009",
			"frame": {"x":612,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 3 copy instance 10010",
			"frame": {"x":680,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 3 copy instance 10011",
			"frame": {"x":748,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "number pad.png",
			"format": "RGBA8888",
			"size": {"w":817,"h":69},
			"scale": "1"
		}
		},

	speakerJson: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"sourceSize": { "w": 41, "h": 30 }
			},
			{
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 0, "y": 30, "w": 41, "h": 30 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"sourceSize": { "w": 41, "h": 30 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "s.png",
			"format": "RGB8",
			"size": { "w": 44, "h": 64 },
			"scale": "1"
		}
	},

	btnJson: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"sourceSize": { "w": 212, "h": 71 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 0, "y": 71, "w": 212, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"sourceSize": { "w": 212, "h": 71 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "16.5.1.104",
			"image": "b1.png",
			"format": "RGB8",
			"size": { "w": 213, "h": 144 },
			"scale": "1"
		}
	},

	replyJson: {
		"frames": [

			{
				"filename": "Symbol 8 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}
			, {
				"filename": "Symbol 8 instance 10001",
				"frame": { "x": 47, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}
			, {
				"filename": "Symbol 8 instance 10002",
				"frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "Back btn.png",
			"format": "RGBA8888",
			"size": { "w": 98, "h": 48 },
			"scale": "1"
		}
	},

	backbtnJson: {
		"frames": [

			{
				"filename": "Symbol 9 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"sourceSize": { "w": 41, "h": 29 }
			}
			, {
				"filename": "Symbol 9 instance 10001",
				"frame": { "x": 0, "y": 29, "w": 41, "h": 29 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"sourceSize": { "w": 41, "h": 29 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "back.png",
			"format": "RGB8",
			"size": { "w": 44, "h": 64 },
			"scale": "1"
		}
	},

	tickJson: {
		"frames": [

			{
				"filename": "Symbol 10 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"sourceSize": { "w": 68, "h": 66 }
			}
			, {
				"filename": "Symbol 10 copy instance 10001",
				"frame": { "x": 68, "y": 0, "w": 68, "h": 66 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"sourceSize": { "w": 68, "h": 66 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "Right btn0002.png",
			"format": "RGBA8888",
			"size": { "w": 138, "h": 66 },
			"scale": "1"
		}
	},


	nextbtnJson: {
		"frames": [

			{
				"filename": "Symbol 6 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"sourceSize": { "w": 59, "h": 60 }
			}
			, {
				"filename": "Symbol 6 instance 10001",
				"frame": { "x": 0, "y": 60, "w": 59, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"sourceSize": { "w": 59, "h": 60 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "N.png",
			"format": "RGB8",
			"size": { "w": 64, "h": 128 },
			"scale": "1"
		}
	},
	homebtnJson: {
		"frames": [

			{
				"filename": "Symbol 4 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"sourceSize": { "w": 60, "h": 60 }
			}
			, {
				"filename": "Symbol 4 instance 10001",
				"frame": { "x": 0, "y": 60, "w": 60, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"sourceSize": { "w": 60, "h": 60 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "H.png",
			"format": "RGB8",
			"size": { "w": 64, "h": 128 },
			"scale": "1"
		}

	},

	numberpadJson: {
		"frames": [

			{
				"filename": "Symbol 3 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10001",
				"frame": { "x": 68, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10002",
				"frame": { "x": 136, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10003",
				"frame": { "x": 204, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10004",
				"frame": { "x": 272, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10005",
				"frame": { "x": 340, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10006",
				"frame": { "x": 408, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10007",
				"frame": { "x": 476, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10008",
				"frame": { "x": 544, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10009",
				"frame": { "x": 612, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10010",
				"frame": { "x": 680, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10011",
				"frame": { "x": 748, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10012",
				"frame": { "x": 816, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}
			, {
				"filename": "Symbol 3 instance 10013",
				"frame": { "x": 884, "y": 0, "w": 68, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 68 },
				"sourceSize": { "w": 68, "h": 68 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "number 0 to 9.png",
			"format": "RGBA8888",
			"size": { "w": 953, "h": 68 },
			"scale": "1"
		}
	},

	TickbtnJson: {
		"frames": [

			{
				"filename": "Symbol 10 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 67, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 67, "h": 68 },
				"sourceSize": { "w": 67, "h": 68 }
			}
			, {
				"filename": "Symbol 10 instance 10001",
				"frame": { "x": 67, "y": 0, "w": 67, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 67, "h": 68 },
				"sourceSize": { "w": 67, "h": 68 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "ALP-01-G6.png",
			"format": "RGBA8888",
			"size": { "w": 134, "h": 68 },
			"scale": "1"
		}
	},

	bulbBtnJson: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 66, "y": 0, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10002",
				"frame": { "x": 132, "y": 0, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10003",
				"frame": { "x": 0, "y": 49, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10004",
				"frame": { "x": 66, "y": 49, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10005",
				"frame": { "x": 132, "y": 49, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10006",
				"frame": { "x": 0, "y": 98, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10007",
				"frame": { "x": 66, "y": 98, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10008",
				"frame": { "x": 132, "y": 98, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10009",
				"frame": { "x": 0, "y": 147, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10010",
				"frame": { "x": 66, "y": 147, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10011",
				"frame": { "x": 132, "y": 147, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10012",
				"frame": { "x": 0, "y": 196, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10013",
				"frame": { "x": 66, "y": 196, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10014",
				"frame": { "x": 132, "y": 196, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10015",
				"frame": { "x": 0, "y": 245, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10016",
				"frame": { "x": 66, "y": 245, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10017",
				"frame": { "x": 132, "y": 245, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}
			, {
				"filename": "Symbol 1 instance 10018",
				"frame": { "x": 0, "y": 294, "w": 66, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 66, "h": 49 },
				"sourceSize": { "w": 66, "h": 49 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "bulb anim.png",
			"format": "RGBA8888",
			"size": { "w": 198, "h": 347 },
			"scale": "1"
		}
	},

	eraserJson: {
		"frames": [

			{
				"filename": "Symbol 22 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 61, "h": 62 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 61, "h": 62 },
				"sourceSize": { "w": 61, "h": 62 }
			}
			, {
				"filename": "Symbol 22 instance 10001",
				"frame": { "x": 61, "y": 0, "w": 61, "h": 62 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 61, "h": 62 },
				"sourceSize": { "w": 61, "h": 62 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Btn_2.png",
			"format": "RGBA8888",
			"size": { "w": 126, "h": 62 },
			"scale": "1"
		}
	},

	symbol1Json: {
		"frames": [

			{
				"filename": "Symbol 13 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 91, "h": 90 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 91, "h": 90 },
				"sourceSize": { "w": 91, "h": 90 }
			}
			, {
				"filename": "Symbol 13 instance 10001",
				"frame": { "x": 91, "y": 0, "w": 91, "h": 90 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 91, "h": 90 },
				"sourceSize": { "w": 91, "h": 90 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "symbol_1.png",
			"format": "RGBA8888",
			"size": { "w": 183, "h": 90 },
			"scale": "1"
		}
	},

	symbol2Json: {
		"frames": [

			{
				"filename": "Symbol 13 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 91, "h": 90 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 91, "h": 90 },
				"sourceSize": { "w": 91, "h": 90 }
			}
			, {
				"filename": "Symbol 13 copy instance 10001",
				"frame": { "x": 91, "y": 0, "w": 91, "h": 90 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 91, "h": 90 },
				"sourceSize": { "w": 91, "h": 90 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "symbol_2.png",
			"format": "RGBA8888",
			"size": { "w": 183, "h": 90 },
			"scale": "1"
		}
	},

	symbol3Json: {
		"frames": [

			{
				"filename": "Symbol 13 copy 2 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 91, "h": 90 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 91, "h": 90 },
				"sourceSize": { "w": 91, "h": 90 }
			}
			, {
				"filename": "Symbol 13 copy 2 instance 10001",
				"frame": { "x": 91, "y": 0, "w": 91, "h": 90 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 91, "h": 90 },
				"sourceSize": { "w": 91, "h": 90 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "symbol_3.png",
			"format": "RGBA8888",
			"size": { "w": 183, "h": 90 },
			"scale": "1"
		}
	},

	btn_1Json: {
		"frames": [

			{
				"filename": "Symbol 21 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 63, "h": 62 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 63, "h": 62 },
				"sourceSize": { "w": 63, "h": 62 }
			}
			, {
				"filename": "Symbol 21 instance 10001",
				"frame": { "x": 63, "y": 0, "w": 63, "h": 62 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 63, "h": 62 },
				"sourceSize": { "w": 63, "h": 62 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Btn_1.png",
			"format": "RGBA8888",
			"size": { "w": 126, "h": 62 },
			"scale": "1"
		}
	},

	greenBig1Json: {
		"frames": [

			{
				"filename": "Symbol 13 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 34, "h": 129 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 34, "h": 129 },
				"sourceSize": { "w": 34, "h": 129 }
			}
			, {
				"filename": "Symbol 13 instance 10001",
				"frame": { "x": 34, "y": 0, "w": 34, "h": 129 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 34, "h": 129 },
				"sourceSize": { "w": 34, "h": 129 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "green bigg_1.png",
			"format": "RGBA8888",
			"size": { "w": 70, "h": 134 },
			"scale": "1"
		}
	},

	greenBig2Json: {
		"frames": [

			{
				"filename": "Symbol 13 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 129, "h": 35 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 129, "h": 35 },
				"sourceSize": { "w": 129, "h": 35 }
			}
			, {
				"filename": "Symbol 13 instance 10001",
				"frame": { "x": 0, "y": 35, "w": 129, "h": 35 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 129, "h": 35 },
				"sourceSize": { "w": 129, "h": 35 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "green bigg_2.png",
			"format": "RGBA8888",
			"size": { "w": 133, "h": 75 },
			"scale": "1"
		}
	},

	greenBig3Json: {
		"frames": [

			{
				"filename": "Symbol 12 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 34, "h": 34 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 34, "h": 34 },
				"sourceSize": { "w": 34, "h": 34 }
			}
			, {
				"filename": "Symbol 12 instance 10001",
				"frame": { "x": 34, "y": 0, "w": 34, "h": 34 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 34, "h": 34 },
				"sourceSize": { "w": 34, "h": 34 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "green bigg_3.png",
			"format": "RGBA8888",
			"size": { "w": 70, "h": 35 },
			"scale": "1"
		}
	},

	pinkBig1Json: {
		"frames": [

			{
				"filename": "Symbol 11 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 36, "h": 130 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 36, "h": 130 },
				"sourceSize": { "w": 36, "h": 130 }
			}
			, {
				"filename": "Symbol 11 instance 10001",
				"frame": { "x": 36, "y": 0, "w": 36, "h": 130 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 36, "h": 130 },
				"sourceSize": { "w": 36, "h": 130 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "pink bigg_1.png",
			"format": "RGBA8888",
			"size": { "w": 80, "h": 131 },
			"scale": "1"
		}
	},

	pinkBig2Json: {
		"frames": [

			{
				"filename": "Symbol 11 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 130, "h": 36 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 130, "h": 36 },
				"sourceSize": { "w": 130, "h": 36 }
			}
			, {
				"filename": "Symbol 11 instance 10001",
				"frame": { "x": 0, "y": 36, "w": 130, "h": 36 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 130, "h": 36 },
				"sourceSize": { "w": 130, "h": 36 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "pink bigg_2.png",
			"format": "RGBA8888",
			"size": { "w": 135, "h": 73 },
			"scale": "1"
		}
	},

	pinkBig3Json: {
		"frames": [

			{
				"filename": "Symbol 19 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 37, "h": 36 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 37, "h": 36 },
				"sourceSize": { "w": 37, "h": 36 }
			}
			, {
				"filename": "Symbol 19 instance 10001",
				"frame": { "x": 37, "y": 0, "w": 37, "h": 36 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 37, "h": 36 },
				"sourceSize": { "w": 37, "h": 36 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "pink bigg_3.png",
			"format": "RGBA8888",
			"size": { "w": 76, "h": 36 },
			"scale": "1"
		}
	},

	Textbox1Json: {
		"frames": [

			{
				"filename": "Symbol 2 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 300, "h": 77 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 300, "h": 77 },
				"sourceSize": { "w": 300, "h": 77 }
			}
			, {
				"filename": "Symbol 2 instance 10001",
				"frame": { "x": 300, "y": 0, "w": 300, "h": 77 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 300, "h": 77 },
				"sourceSize": { "w": 300, "h": 77 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "text box_1.png",
			"format": "RGBA8888",
			"size": { "w": 600, "h": 78 },
			"scale": "1"
		}
	},

	all_2Json: {
		"frames": [

			{
				"filename": "Symbol 29 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 127, "h": 127 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 127, "h": 127 },
				"sourceSize": { "w": 127, "h": 127 }
			}
			, {
				"filename": "Symbol 29 instance 10001",
				"frame": { "x": 127, "y": 0, "w": 127, "h": 127 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 127, "h": 127 },
				"sourceSize": { "w": 127, "h": 127 }
			}
			, {
				"filename": "Symbol 29 instance 10002",
				"frame": { "x": 254, "y": 0, "w": 127, "h": 127 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 127, "h": 127 },
				"sourceSize": { "w": 127, "h": 127 }
			}
			, {
				"filename": "Symbol 29 instance 10003",
				"frame": { "x": 381, "y": 0, "w": 127, "h": 127 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 127, "h": 127 },
				"sourceSize": { "w": 127, "h": 127 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "all_2.png",
			"format": "RGBA8888",
			"size": { "w": 509, "h": 129 },
			"scale": "1"
		}
	},

	all_4Json: {
		"frames": [

			{
				"filename": "Symbol 29 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 88, "h": 88 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 88, "h": 88 },
				"sourceSize": { "w": 88, "h": 88 }
			}
			, {
				"filename": "Symbol 29 instance 10001",
				"frame": { "x": 88, "y": 0, "w": 88, "h": 88 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 88, "h": 88 },
				"sourceSize": { "w": 88, "h": 88 }
			}
			, {
				"filename": "Symbol 29 instance 10002",
				"frame": { "x": 176, "y": 0, "w": 88, "h": 88 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 88, "h": 88 },
				"sourceSize": { "w": 88, "h": 88 }
			}
			, {
				"filename": "Symbol 29 instance 10003",
				"frame": { "x": 264, "y": 0, "w": 88, "h": 88 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 88, "h": 88 },
				"sourceSize": { "w": 88, "h": 88 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "all_4.png",
			"format": "RGBA8888",
			"size": { "w": 354, "h": 88 },
			"scale": "1"
		}
	},

	Textbox5Json: {
		"frames": [

			{
				"filename": "Symbol 14 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 56, "h": 40 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 56, "h": 40 },
				"sourceSize": { "w": 56, "h": 40 }
			}
			, {
				"filename": "Symbol 14 instance 10001",
				"frame": { "x": 56, "y": 0, "w": 56, "h": 40 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 56, "h": 40 },
				"sourceSize": { "w": 56, "h": 40 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "text box_5.png",
			"format": "RGBA8888",
			"size": { "w": 115, "h": 40 },
			"scale": "1"
		}
	},
	green1Json: {
		"frames": [

			{
				"filename": "Symbol 21 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 33, "h": 126 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 126 },
				"sourceSize": { "w": 33, "h": 126 }
			}
			, {
				"filename": "Symbol 21 instance 10001",
				"frame": { "x": 33, "y": 0, "w": 33, "h": 126 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 126 },
				"sourceSize": { "w": 33, "h": 126 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "green_2.1.png",
			"format": "RGBA8888",
			"size": { "w": 66, "h": 128 },
			"scale": "1"
		}
	},
	green2Json: {
		"frames": [

			{
				"filename": "Symbol 21 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 127, "h": 33 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 127, "h": 33 },
				"sourceSize": { "w": 127, "h": 33 }
			}
			, {
				"filename": "Symbol 21 instance 10001",
				"frame": { "x": 0, "y": 33, "w": 127, "h": 33 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 127, "h": 33 },
				"sourceSize": { "w": 127, "h": 33 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "green_2.2.png",
			"format": "RGBA8888",
			"size": { "w": 128, "h": 70 },
			"scale": "1"
		}
	},
	pink1Json: {
		"frames": [

			{
				"filename": "Symbol 21 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 33, "h": 126 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 126 },
				"sourceSize": { "w": 33, "h": 126 }
			}
			, {
				"filename": "Symbol 21 instance 10001",
				"frame": { "x": 33, "y": 0, "w": 33, "h": 126 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 126 },
				"sourceSize": { "w": 33, "h": 126 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "pink_2.1.png",
			"format": "RGBA8888",
			"size": { "w": 69, "h": 128 },
			"scale": "1"
		}
	},
	pink2Json: {
		"frames": [

			{
				"filename": "Symbol 23 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 127, "h": 33 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 127, "h": 33 },
				"sourceSize": { "w": 127, "h": 33 }
			}
			, {
				"filename": "Symbol 23 instance 10001",
				"frame": { "x": 127, "y": 0, "w": 127, "h": 33 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 127, "h": 33 },
				"sourceSize": { "w": 127, "h": 33 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "pink_2.2.png",
			"format": "RGBA8888",
			"size": { "w": 255, "h": 35 },
			"scale": "1"
		}
	},

	all_1Json: {
		"frames": [

			{
				"filename": "Symbol 32 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 127, "h": 87 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 127, "h": 87 },
				"sourceSize": { "w": 127, "h": 87 }
			}
			, {
				"filename": "Symbol 32 instance 10001",
				"frame": { "x": 127, "y": 0, "w": 127, "h": 87 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 127, "h": 87 },
				"sourceSize": { "w": 127, "h": 87 }
			}
			, {
				"filename": "Symbol 32 instance 10002",
				"frame": { "x": 254, "y": 0, "w": 127, "h": 87 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 127, "h": 87 },
				"sourceSize": { "w": 127, "h": 87 }
			}
			, {
				"filename": "Symbol 32 instance 10003",
				"frame": { "x": 381, "y": 0, "w": 127, "h": 87 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 127, "h": 87 },
				"sourceSize": { "w": 127, "h": 87 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "all_1.png",
			"format": "RGBA8888",
			"size": { "w": 509, "h": 88 },
			"scale": "1"
		}
	},

	all_3Json: {
		"frames": [

			{
				"filename": "Symbol 32 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 88, "h": 126 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 88, "h": 126 },
				"sourceSize": { "w": 88, "h": 126 }
			}
			, {
				"filename": "Symbol 32 instance 10001",
				"frame": { "x": 88, "y": 0, "w": 88, "h": 126 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 88, "h": 126 },
				"sourceSize": { "w": 88, "h": 126 }
			}
			, {
				"filename": "Symbol 32 instance 10002",
				"frame": { "x": 176, "y": 0, "w": 88, "h": 126 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 88, "h": 126 },
				"sourceSize": { "w": 88, "h": 126 }
			}
			, {
				"filename": "Symbol 32 instance 10003",
				"frame": { "x": 264, "y": 0, "w": 88, "h": 126 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 88, "h": 126 },
				"sourceSize": { "w": 88, "h": 126 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "all_3.png",
			"format": "RGBA8888",
			"size": { "w": 354, "h": 129 },
			"scale": "1"
		}
	},

	green3Json: {
		"frames": [

			{
				"filename": "Symbol 22 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 88, "h": 33 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 88, "h": 33 },
				"sourceSize": { "w": 88, "h": 33 }
			}
			, {
				"filename": "Symbol 22 instance 10001",
				"frame": { "x": 0, "y": 33, "w": 88, "h": 33 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 88, "h": 33 },
				"sourceSize": { "w": 88, "h": 33 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "green_2.3.png",
			"format": "RGBA8888",
			"size": { "w": 90, "h": 70 },
			"scale": "1"
		}
	},

	green4Json: {
		"frames": [

			{
				"filename": "Symbol 22 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 33, "h": 87 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 87 },
				"sourceSize": { "w": 33, "h": 87 }
			}
			, {
				"filename": "Symbol 22 instance 10001",
				"frame": { "x": 33, "y": 0, "w": 33, "h": 87 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 87 },
				"sourceSize": { "w": 33, "h": 87 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "green_2.4.png",
			"format": "RGBA8888",
			"size": { "w": 68, "h": 88 },
			"scale": "1"
		}
	},

	pink3Json: {
		"frames": [

			{
				"filename": "Symbol 19 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 88, "h": 33 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 88, "h": 33 },
				"sourceSize": { "w": 88, "h": 33 }
			}
			, {
				"filename": "Symbol 19 instance 10001",
				"frame": { "x": 88, "y": 0, "w": 88, "h": 33 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 88, "h": 33 },
				"sourceSize": { "w": 88, "h": 33 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "pink_2.3.png",
			"format": "RGBA8888",
			"size": { "w": 177, "h": 35 },
			"scale": "1"
		}
	},

	pink4Json: {
		"frames": [

			{
				"filename": "Symbol 22 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 33, "h": 87 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 87 },
				"sourceSize": { "w": 33, "h": 87 }
			}
			, {
				"filename": "Symbol 22 instance 10001",
				"frame": { "x": 33, "y": 0, "w": 33, "h": 87 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 87 },
				"sourceSize": { "w": 33, "h": 87 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "pink_2.4.png",
			"format": "RGBA8888",
			"size": { "w": 69, "h": 90 },
			"scale": "1"
		}
	},

	SymbolJson: {
		"frames": [

			{
				"filename": "Symbol 13 copy 2 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 91, "h": 90 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 91, "h": 90 },
				"sourceSize": { "w": 91, "h": 90 }
			}
			, {
				"filename": "Symbol 13 copy 2 instance 10001",
				"frame": { "x": 91, "y": 0, "w": 91, "h": 90 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 91, "h": 90 },
				"sourceSize": { "w": 91, "h": 90 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "symbol_3.png",
			"format": "RGBA8888",
			"size": { "w": 183, "h": 90 },
			"scale": "1"
		}
	},

	thumsup_1: {
		"frames": [

			{
				"filename": "Symbol 2 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 62, "h": 63 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 62, "h": 63 },
				"sourceSize": { "w": 62, "h": 63 }
			}
			, {
				"filename": "Symbol 2 copy instance 10001",
				"frame": { "x": 62, "y": 0, "w": 62, "h": 63 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 62, "h": 63 },
				"sourceSize": { "w": 62, "h": 63 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "thumsup_1.png",
			"format": "RGBA8888",
			"size": { "w": 126, "h": 63 },
			"scale": "1"
		}
	},

	thumsdown_1: {
		"frames": [

			{
				"filename": "Symbol 3 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 62, "h": 62 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 62, "h": 62 },
				"sourceSize": { "w": 62, "h": 62 }
			}
			, {
				"filename": "Symbol 3 instance 10001",
				"frame": { "x": 62, "y": 0, "w": 62, "h": 62 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 62, "h": 62 },
				"sourceSize": { "w": 62, "h": 62 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "thumsdown_1.png",
			"format": "RGBA8888",
			"size": { "w": 126, "h": 63 },
			"scale": "1"
		}
	},

	Box2: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 212, "h": 216 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 216 },
				"sourceSize": { "w": 212, "h": 216 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 212, "y": 0, "w": 212, "h": 216 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 216 },
				"sourceSize": { "w": 212, "h": 216 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "box 2.png",
			"format": "RGBA8888",
			"size": { "w": 425, "h": 218 },
			"scale": "1"
		}

	},

	Bx2frame: {
		"frames": [

			{
				"filename": "Symbol 31 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 162, "h": 152 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 162, "h": 152 },
				"sourceSize": { "w": 162, "h": 152 }
			}
			, {
				"filename": "Symbol 31 copy instance 10001",
				"frame": { "x": 162, "y": 0, "w": 162, "h": 152 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 162, "h": 152 },
				"sourceSize": { "w": 162, "h": 152 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "box.png",
			"format": "RGBA8888",
			"size": { "w": 327, "h": 154 },
			"scale": "1"
		}

	},
	
	box2New :{"frames": [

		{
			"filename": "Symbol 1 instance 10000",
			"frame": {"x":0,"y":0,"w":143,"h":146},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":143,"h":146},
			"sourceSize": {"w":143,"h":146}
		}
		,{
			"filename": "Symbol 1 instance 10001",
			"frame": {"x":143,"y":0,"w":143,"h":146},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":143,"h":146},
			"sourceSize": {"w":143,"h":146}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Box_2new.png",
			"format": "RGBA8888",
			"size": {"w":287,"h":148},
			"scale": "1"
		}
		}
		
};

