Game.preloader_GMM_01_G8 = function (game) {
        this.preloadBar = null;
};

var chime, clockTick;
Game.preloader_GMM_01_G8.prototype = {
        preload: function () {

                // this.load.video('ML1_1', 'demoVideos/ML1-G7_1.mp4');   //* include demo video of ML-2 game.
                // this.load.video('ML1_2', 'demoVideos/ML1-G7_2.mp4');   //* include demo video of ML-2 game.

                this.load.atlas('bulb', 'assets/commonAssets/bulb.png', null, GMM_01_G8_JSON.bulbBtnJson);
                this.load.image('skipArrow', 'assets/commonAssets/skipArrow.png');

                this.load.atlas('backbtn', 'assets/commonAssets/backbtn.png', null, GMM_01_G8_JSON.backbtnJson);
                this.load.atlas('CommonSpeakerBtn', 'assets/commonAssets/speaker.png', null, GMM_01_G8_JSON.speakerJson);
                this.load.atlas('starAnim', 'assets/commonAssets/starAnim.png', null, GMM_01_G8_JSON.starAnimJson);
                this.load.atlas('replay', 'assets/commonAssets/reply.png', null, GMM_01_G8_JSON.replyJson);
                this.load.image('navBar', 'assets/commonAssets/navBar.png');
                this.load.image('timebg', 'assets/commonAssets/timebg.png');
                this.load.image('hand', 'assets/commonAssets/hand.png');
                this.load.atlas('CommonHomeBtn', 'assets/commonAssets/homeBtn.png', null, GMM_01_G8_JSON.homebtnJson);
                this.load.atlas('CommonNextBtn', 'assets/commonAssets/nextBtn.png', null, GMM_01_G8_JSON.nextbtnJson);
                this.load.image('bg', 'assets/gradeAssets/GMM-01-G8/BG.png');



                this.load.image('dotedRectangle', 'assets/gradeAssets/GMM-01-G8/doted objct_1.png');
                this.load.image('dotedTriangle', 'assets/gradeAssets/GMM-01-G8/doted objct_2.png');
                this.load.image('dotedSquare', 'assets/gradeAssets/GMM-01-G8/doted box 1.png');
                this.load.image('dotedParallogram', 'assets/gradeAssets/GMM-01-G8/doted box 2.png');

                this.load.image('lineTr', 'assets/gradeAssets/GMM-01-G8/line_1M.png');
                this.load.image('linetrBig', 'assets/gradeAssets/GMM-01-G8/line_3Big.png');

                this.load.image('line2', 'assets/gradeAssets/GMM-01-G8/line_2M.png');
                this.load.image('line3', 'assets/gradeAssets/GMM-01-G8/line_3M.png');
                this.load.image('line3hr', 'assets/gradeAssets/GMM-01-G8/line_3MHr.png');
                this.load.image('line3Big', 'assets/gradeAssets/GMM-01-G8/line_3M big.png');



                this.load.image('Box2', 'assets/gradeAssets/GMM-01-G8/box2.png');
                this.load.atlas('box1', 'assets/gradeAssets/GMM-01-G8/box1.png', null, GMM_01_G8_JSON.box1);


                this.load.image('answerBox', 'assets/gradeAssets/GMM-01-G8/text box.png');
                this.load.image('textBox1', 'assets/gradeAssets/GMM-01-G8/text box_30001.png');
                this.load.image('textBox1Yellow', 'assets/gradeAssets/GMM-01-G8/text box_30002.png');
                this.load.atlas('textBox2', 'assets/gradeAssets/GMM-01-G8/text box_2.png', null, GMM_01_G8_JSON.textBox2);

                this.load.atlas('rect1', 'assets/gradeAssets/GMM-01-G8/Shape_3.0.png', null, GMM_01_G8_JSON.rect1);
                this.load.atlas('rect2', 'assets/gradeAssets/GMM-01-G8/Shape_3.1.png', null, GMM_01_G8_JSON.rect2);
                this.load.atlas('rect3', 'assets/gradeAssets/GMM-01-G8/Shape_3.2.png', null, GMM_01_G8_JSON.rect3);

                this.load.atlas('tr1', 'assets/gradeAssets/GMM-01-G8/triangle1.png', null, GMM_01_G8_JSON.tr1);
                this.load.atlas('tr2', 'assets/gradeAssets/GMM-01-G8/triangle2.png', null, GMM_01_G8_JSON.tr2);
                this.load.atlas('tr3', 'assets/gradeAssets/GMM-01-G8/triangle3.png', null, GMM_01_G8_JSON.tr3);

                this.load.atlas('parl1', 'assets/gradeAssets/GMM-01-G8/parelel1.png', null, GMM_01_G8_JSON.parl1);
                this.load.atlas('parl2', 'assets/gradeAssets/GMM-01-G8/parelel2.png', null, GMM_01_G8_JSON.parl2);
                this.load.atlas('parl3', 'assets/gradeAssets/GMM-01-G8/parelel3.png', null, GMM_01_G8_JSON.parl3);

                this.load.atlas('eqTr', 'assets/gradeAssets/GMM-01-G8/Shape_8.0.png', null, GMM_01_G8_JSON.eqtr);

                this.load.atlas('scalTr', 'assets/gradeAssets/GMM-01-G8/Shape_8.1.png', null, GMM_01_G8_JSON.scltr);
                this.load.atlas('isoTr', 'assets/gradeAssets/GMM-01-G8/Shape_8.2.png', null, GMM_01_G8_JSON.isotr);


                this.load.atlas('pinkParl', 'assets/gradeAssets/GMM-01-G8/Shape_9.0.png', null, GMM_01_G8_JSON.pinkParalogram);

                this.load.atlas('sqG1', 'assets/gradeAssets/GMM-01-G8/Shape_2.0.png', null, GMM_01_G8_JSON.sqGr1);
                this.load.atlas('sqG2', 'assets/gradeAssets/GMM-01-G8/Shape_2.1.png', null, GMM_01_G8_JSON.sqGr2);
                this.load.atlas('sqG3', 'assets/gradeAssets/GMM-01-G8/Shape_2.2.png', null, GMM_01_G8_JSON.sqGr3);

                this.load.atlas('pinkBox1', 'assets/gradeAssets/GMM-01-G8/pink box1.png', null, GMM_01_G8_JSON.pinkB1);
                this.load.atlas('pinkBox', 'assets/gradeAssets/GMM-01-G8/pink box.png', null, GMM_01_G8_JSON.pinbox);

                this.load.atlas('pinkBox2', 'assets/gradeAssets/GMM-01-G8/pink box2.png', null, GMM_01_G8_JSON.pinkB2);
                this.load.atlas('pinkBox3', 'assets/gradeAssets/GMM-01-G8/pink box3.png', null, GMM_01_G8_JSON.pinkB3);

                this.load.atlas('pinkrect1', 'assets/gradeAssets/GMM-01-G8/rectshape1.png', null, GMM_01_G8_JSON.pinkRect1);
                this.load.atlas('pinkrect2', 'assets/gradeAssets/GMM-01-G8/rectshape2.png', null, GMM_01_G8_JSON.pinkRect2);
                this.load.atlas('pinkrect3', 'assets/gradeAssets/GMM-01-G8/rectshape3.png', null, GMM_01_G8_JSON.pinkRect3);


        
                this.load.atlas('TickBtn', 'assets/gradeAssets/GMM-01-G8/TickBtn.png', null, GMM_01_G8_JSON.tickJson);
                this.load.atlas('Numberpad', 'assets/gradeAssets/GMM-01-G8/number pad.png', null, GMM_01_G8_JSON.numberpadJson)
                this.load.image('numpadbg', 'assets/gradeAssets/GMM-01-G8/numbg.png');


        },

        create: function () {
                this.state.start('GMM_01_G8level1');
        },
}